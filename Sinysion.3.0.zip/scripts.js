// scripts.js - Sinysion Enhanced Interactions

let ticking = false

document.addEventListener("mousemove", (e) => {
  if (!ticking) {
    requestAnimationFrame(() => {
      const heroParallax = document.getElementById("heroParallax")
      const heroCard = document.getElementById("heroCard")

      if (heroParallax) {
        const x = e.clientX / window.innerWidth - 0.5
        const y = e.clientY / window.innerHeight - 0.5
        heroParallax.style.transform = `translate(${x * 12}px, ${y * 12}px)`
      }

      if (heroCard) {
        const rect = heroCard.getBoundingClientRect()
        const centerX = rect.left + rect.width / 2
        const centerY = rect.top + rect.height / 2
        const rotateX = (e.clientY - centerY) / 10
        const rotateY = (centerX - e.clientX) / 10
        heroCard.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`
      }

      ticking = false
    })
    ticking = true
  }
})

let testiIndex = 0
const slides = document.querySelectorAll(".carousel .slide")
const totalSlides = slides.length

function showTesti(i) {
  slides.forEach((s, index) => {
    s.classList.remove("active")
    if (index === i) {
      s.classList.add("active")
    }
  })
}

function nextTesti() {
  testiIndex = (testiIndex + 1) % totalSlides
  showTesti(testiIndex)
}

function prevTesti() {
  testiIndex = (testiIndex - 1 + totalSlides) % totalSlides
  showTesti(testiIndex)
}

// Make functions globally available
window.nextTesti = nextTesti
window.prevTesti = prevTesti

let autoplayInterval

function startAutoplay() {
  autoplayInterval = setInterval(nextTesti, 5000)
}

function stopAutoplay() {
  clearInterval(autoplayInterval)
}

const carousel = document.querySelector(".carousel")
if (carousel) {
  carousel.addEventListener("mouseenter", stopAutoplay)
  carousel.addEventListener("mouseleave", startAutoplay)
  startAutoplay()
}

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const targetId = this.getAttribute("href")
    const target = document.querySelector(targetId)

    if (target) {
      e.preventDefault()
      const headerHeight = document.querySelector(".header").offsetHeight
      const targetPosition = target.offsetTop - headerHeight - 20

      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      })
    }
  })
})

function toggleNav() {
  document.body.classList.toggle("nav-open")
}

window.toggleNav = toggleNav

let lastScrollY = window.scrollY

window.addEventListener("scroll", () => {
  const header = document.querySelector(".header")
  const currentScrollY = window.scrollY

  if (header) {
    if (currentScrollY > 100) {
      header.style.background = "rgba(10, 14, 26, 0.98)"
      header.style.backdropFilter = "blur(20px)"
    } else {
      header.style.background = "rgba(10, 14, 26, 0.95)"
      header.style.backdropFilter = "blur(20px)"
    }
  }

  lastScrollY = currentScrollY
})

const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -50px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

document.addEventListener("DOMContentLoaded", () => {
  const animateElements = document.querySelectorAll(".card, .benefit, .post, .plan")

  animateElements.forEach((el) => {
    el.style.opacity = "0"
    el.style.transform = "translateY(30px)"
    el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(el)
  })
})

const contactForm = document.querySelector(".contact-form")
if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    const submitBtn = this.querySelector(".submit-btn")
    const originalText = submitBtn.innerHTML

    submitBtn.innerHTML = "<span>Enviando...</span>"
    submitBtn.disabled = true

    // Reset after form submission (this would be handled by PHP in real implementation)
    setTimeout(() => {
      submitBtn.innerHTML = originalText
      submitBtn.disabled = false
    }, 2000)
  })
}

document.addEventListener("DOMContentLoaded", () => {
  const serverUnits = document.querySelectorAll(".server-unit")

  serverUnits.forEach((unit, index) => {
    setTimeout(() => {
      unit.classList.add("active")
      setTimeout(() => {
        unit.classList.remove("active")
      }, 2000)
    }, index * 1000)
  })

  // Repeat animation every 6 seconds
  setInterval(() => {
    serverUnits.forEach((unit, index) => {
      setTimeout(() => {
        unit.classList.add("active")
        setTimeout(() => {
          unit.classList.remove("active")
        }, 2000)
      }, index * 1000)
    })
  }, 6000)
})

function debounce(func, wait) {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

const handleResize = debounce(() => {
  // Handle responsive adjustments if needed
  const heroCard = document.getElementById("heroCard")
  if (heroCard && window.innerWidth <= 768) {
    heroCard.style.transform = "none"
  }
}, 250)

window.addEventListener("resize", handleResize)

function toggleNav() {
  document.body.classList.toggle("nav-open");
  // Add a class to the hamburger button when the menu is open
  const burger = document.querySelector('.burger');
  if (document.body.classList.contains("nav-open")) {
    burger.classList.add("is-active");
  } else {
    burger.classList.remove("is-active");
  }
}

document.querySelectorAll('.dropdown > a').forEach(link => {
  link.addEventListener('click', function(e) {
    if (window.innerWidth <= 640) {
      e.preventDefault();
      const parent = this.closest('.dropdown');
      parent.classList.toggle('open');
    }
  });
});
document.addEventListener('DOMContentLoaded', function() {
  const dropdowns = document.querySelectorAll('.dropdown');

  dropdowns.forEach(drop => {
    // Escucha el evento 'mouseenter' para abrir el menú
    drop.addEventListener('mouseenter', function() {
      // Abre solo el menú actual
      this.classList.add('open-menu');
    });

    // Escucha el evento 'mouseleave' para cerrar el menú
    drop.addEventListener('mouseleave', function() {
      // Cierra el menú al salir
      this.classList.remove('open-menu');
    });
  });

  // Opcional: Cierra el menú si se hace clic fuera de él
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.dropdown')) {
      dropdowns.forEach(drop => {
        drop.classList.remove('open-menu');
      });
    }
  });
});
