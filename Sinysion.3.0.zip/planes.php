<?php include("inc/header.php"); ?>
  <section id="planes" class="section dark-section">
    <div class="container">
      <h3 class="section-title light">Compará planes</h3>
      <div class="plans-table">
        <div class="plan">
          <h4>Básico</h4>
          <p class="price">$3.990/anu.</p>
          <ul>
            <li>2 GB RAM</li>
            <li>1 vCPU</li>
            <li>20 GB NVMe</li>
          </ul>
          <a class="btn-primary" href="#contacto">Contratar</a>
        </div>
        <div class="plan recommended">
          <h4>Negocio</h4>
          <p class="price">$6.990/anu.</p>
          <ul>
            <li>4 GB RAM</li>
            <li>2 vCPU</li>
            <li>50 GB NVMe</li>
          </ul>
          <a class="btn-primary" href="#contacto">Contratar</a>
        </div>
        <div class="plan">
          <h4>Empresa</h4>
          <p class="price">$12.990/anu.</p>
          <ul>
            <li>8 GB RAM</li>
            <li>4 vCPU</li>
            <li>120 GB NVMe</li>
          </ul>
          <a class="btn-primary" href="#contacto">Contratar</a>
        </div>
      </div>

      <h4 class="mt-40">Game Panels</h4>
      <div class="plans-table">
        <div class="plan">
          <h4>Game Panel 1</h4>
          <p class="price">$2.990/mes</p>
          <ul>
            <li>2 GB RAM</li>
            <li>1 vCPU</li>
            <li>20 GB</li>
          </ul>
          <a class="btn-outline" href="#contacto">Contratar</a>
        </div>
        <div class="plan recommended">
          <h4>Game Panel 2</h4>
          <p class="price">$4.990/mes</p>
          <ul>
            <li>4 GB RAM</li>
            <li>2 vCPU</li>
            <li>50 GB</li>
          </ul>
          <a class="btn-primary" href="#contacto">Contratar</a>
        </div>
        <div class="plan">
          <h4>Game Panel 3</h4>
          <p class="price">$8.990/mes</p>
          <ul>
            <li>8 GB RAM</li>
            <li>4 vCPU</li>
            <li>120 GB</li>
          </ul>
          <a class="btn-outline" href="#contacto">Contratar</a>
        </div>
      </div>
    </div>
  </section>
<?php include("inc/footer.php"); ?>