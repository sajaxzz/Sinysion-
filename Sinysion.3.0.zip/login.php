<?php
session_start();
include 'inc/header.php';
?>
<section class="form-page">
  <div class="form-card">
    <h3 class="section-title">Iniciar Sesión</h3>
    
    <?php if (isset($_SESSION['error_message'])): ?>
      <div class="error-message">
        <p><?= htmlspecialchars($_SESSION['error_message']) ?></p>
      </div>
      <?php unset($_SESSION['error_message']); // Limpia el mensaje para que no se muestre de nuevo ?>
    <?php endif; ?>

    <form action="auth.php" method="post" class="auth-form">
      <label>Email
        <input type="email" name="email" required>
      </label>
      <label>Contraseña
        <input type="password" name="password" required>
      </label>
      <button class="btn-primary" type="submit">Acceder</button>
      <div class="form-link">
        <p>¿Aún no tienes una cuenta? <a href="register.php">Regístrate</p>
      </div>
    </form>
  </div>
</section>
<?php include 'inc/footer.php'; ?>