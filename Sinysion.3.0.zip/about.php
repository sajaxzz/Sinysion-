<?php 
// about.php - Página sobre nosotros
$title = "Sobre Nosotros - Sinysion";
include 'inc/header.php';
?>

<section class="section">
    <div class="container" style="max-width: 800px;">
        <h3 class="section-title">Nuestra Historia</h3>
        <p class="lead">
            Sinysion nació en Argentina en un momento de grandes cambios. Durante la pandemia y la cuarentena, el país fue testigo de un fenómeno único: el crecimiento acelerado de emprendimientos digitales y el surgimiento de una nueva generación de creadores de contenido con comunidades sólidas. Aunque pertenecían a mundos distintos, ambos compartían una misma necesidad: servidores estables, accesibles y con baja latencia local.
        </p>
        <p class="lead">
            Los emprendedores buscaban un lugar confiable para alojar sus páginas web y poder vender sus productos y servicios. Al mismo tiempo, los creadores de contenido necesitaban servidores de juego donde compartir experiencias con sus comunidades. De esa unión de necesidades surgió Sinysion.
        </p>

        <h4 class="section-title" style="margin-top: 50px;">Nuestro nombre refleja nuestra esencia:</h4>
        <ul class="about-list">
            <li>
                <strong>Sinergia</strong>, que significa cooperación profunda y verdadera, la unión con nuestros clientes para crecer juntos.
            </li>
            <li>
                <strong>Visión</strong>, que representa el futuro al que apuntamos, adoptando nuevas tecnologías y anticipándonos a las necesidades del mercado digital.
            </li>
        </ul>
    </div>
</section>

<?php include 'inc/footer.php'; ?>