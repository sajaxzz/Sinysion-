<?php include("inc/header.php"); ?>
<section class="section">
  <div class="container">
    <h2>Soporte por Discord</h2>
    <p>Unite a nuestra comunidad en Discord para soporte directo y rápido.</p>
    <a href="https://discord.gg/tuservidor" class="btn-primary">Unirme al Discord</a>
  </div>
</section>
<?php include("inc/footer.php"); ?>