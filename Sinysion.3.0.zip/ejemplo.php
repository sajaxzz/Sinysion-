<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ejemplo Menú Desplegable</title>
  <style>
    /* Reset básico */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
    }

    nav {
      background-color: #333;
      position: relative;
    }

    .menu {
      list-style: none;
      display: flex;
      flex-wrap: wrap;
    }

    .menu li {
      position: relative;
    }

    .menu a {
      display: block;
      padding: 15px 20px;
      color: white;
      text-decoration: none;
    }

    .menu li:hover {
      background-color: #444;
    }

    /* Submenú */
    .submenu {
      display: none;
      position: absolute;
      top: 100%;
      left: 0;
      background-color: #444;
      list-style: none;
      min-width: 150px;
    }

    .submenu li a {
      padding: 10px 15px;
    }

    .dropdown:hover .submenu {
      display: block;
    }

    /* Responsive: menú hamburguesa */
    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
      padding: 15px;
    }

    .hamburger div {
      width: 25px;
      height: 3px;
      background-color: white;
      margin: 4px 0;
    }

    @media (max-width: 768px) {
      .menu {
        display: none;
        flex-direction: column;
        width: 100%;
      }

      .menu li {
        width: 100%;
      }

      .submenu {
        position: static;
      }

      .hamburger {
        display: flex;
      }
    }

    /* Sección de ejemplo */
    section {
      padding: 50px;
      text-align: center;
    }
  </style>
</head>
<body>

  <nav>
    <div class="hamburger" onclick="toggleMenu()">
      <div></div>
      <div></div>
      <div></div>
    </div>
    <ul class="menu">
      <li><a href="#">Inicio</a></li>
      <li class="dropdown">
        <a href="#">Servicios</a>
        <ul class="submenu">
          <li><a href="#">Diseño</a></li>
          <li><a href="#">Desarrollo</a></li>
          <li><a href="#">Marketing</a></li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="#">Productos</a>
        <ul class="submenu">
          <li><a href="#">Computadoras</a></li>
          <li><a href="#">Celulares</a></li>
          <li><a href="#">Accesorios</a></li>
        </ul>
      </li>
      <li><a href="#">Contacto</a></li>
    </ul>
  </nav>

  <section>
    <h1>Bienvenido a nuestra página de ejemplo</h1>
    <p>Aquí puedes probar la barra de navegación con menús desplegables.</p>
  </section>

  <script>
    function toggleMenu() {
      const menu = document.querySelector('.menu');
      menu.style.display = menu.style.display === 'flex' ? 'none' : 'flex';
    }
  </script>
  
</body>
</html>
