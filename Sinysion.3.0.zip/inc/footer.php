  </main>

  <footer class="footer">
    <div class="container footer-grid">

      <div class="footer-brand">
        <a href="<?= BASE_URL ?>index.php">
        <img src="<?= BASE_URL ?>assets/logo.png" alt="Sinysion" class="logo-img">
        </a>
        <div class="social-links">
          <a href="https://instagram.com">
            <img src="assets/ig.png" alt="ig" class="redes">
          </a>
          <a href="https://tiktok.com">
            <img src="assets/tt.png" alt="tt" class="redes">
          </a>
          <a href="https://x.com">
            <img src="assets/x.png" alt="x" class="redes">
          </a>
          <a href="https://youtube.com">
            <img src="assets/yt.png" alt="yt" class="redes">
          </a>
          <a href="#">
            <img src="" alt="">
          </a>
        </div>
      </div>

      <!-- Columna 2 -->
      <div>
        <h4>La Empresa 🚀</h4>
        <ul>
          <li><a href="<?= BASE_URL ?>about.php">Sobre nosotros</a></li>
          <li><a href="<?= BASE_URL ?>contact.php">Contacto</a></li>
          <li><a href="#">Nuestros socios</a></li>
          <li><a href="#">Nuestra marca</a></li>
          <li><a href="<?= BASE_URL ?>terms.php">Términos de servicio</a></li>
          <li><a href="<?= BASE_URL ?>privacy.php">Política de privacidad</a></li>
        </ul>
      </div>

      <!-- Columna 3 -->
      <div>
        <h4>Recursos y Ayuda ⭐</h4>
        <ul>
          <li><a href="<?= BASE_URL ?>docs.php">Documentación</a></li>
          <li><a href="<?= BASE_URL ?>payments.php">Métodos de pago</a></li>
          <li><a href="<?= BASE_URL ?>status.php">Estado de servidores</a></li>
          <li><a href="<?= BASE_URL ?>panel.php">Nuestro Panel</a></li>
          <li><a href="<?= BASE_URL ?>mcjars.php">MC Server Jars</a></li>
          <li><a href="<?= BASE_URL ?>ping.php">Ping Tester</a></li>
        </ul>
      </div>

      <!-- Columna 4 -->
      <div>
        <h4>Clientes 💙</h4>
        <ul>
          <li><a href="<?= BASE_URL ?>clients.php">Área de Clientes</a></li>
          <li><a href="<?= BASE_URL ?>gamepanel.php">Game Panel</a></li>
          <li><a href="<?= BASE_URL ?>vpspanel.php">VPS Panel</a></li>
          <li><a href="<?= BASE_URL ?>support-discord.php">Soporte por Discord</a></li>
          <li><a href="<?= BASE_URL ?>support-ticket.php">Soporte por Ticket</a></li>
        </ul>
      </div>

      <!-- Columna 5 -->
      <div>
        <h4>Contáctanos 🤝</h4>
        <ul>
          <li>💬 <a href="#">discord.sinysion.com</a></li>
          <li>📧 <a href="mailto:contacto@sinysion.com">contacto@sinysion.com</a></li>
        </ul>
      </div>

    </div>

    <div class="footer-bottom">
      <div class="left">
        <p>© <?= date("Y") ?> Sinysion. Todos los derechos reservados. Desarrollado por Nahuel para ustedes 🫶</p>
        <p>Registered in Argentina — VAT: 20-47519535-4</p>
      </div>
      <div class="right">
        <img src="<?= BASE_URL ?>assets/data.png" alt="Data Fiscal" class="qr">
      </div>
    </div>
  </footer>

  <script src="<?= BASE_URL ?>scripts.js"></script>
</body>
</html>