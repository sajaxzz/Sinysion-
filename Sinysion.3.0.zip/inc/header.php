<?php
// inc/header.php
if(!defined('BASE_URL')){
  define('BASE_URL', '/sinysion/'); // ruta base, ajustala a tu servidor
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= isset($title) ? htmlspecialchars($title) : 'Sinysion Hosting' ?></title>
  <link rel="stylesheet" href="<?= BASE_URL ?>styles.css">
</head>
<body>
<header class="header">
    <div class="container header-inner">
      <div class="brand">
        <a href="<?= BASE_URL ?>index.php">
        <img src="<?= BASE_URL ?>assets/logo.png" alt="Sinysion" class="logo-img">
        </a>
      </div>
<nav class="nav">
  <ul class="menu">
    <li class="dropdown mega">
      <a href="#">Game Servers</a>
      <div class="mega-menu">
        <div class="column">
         <img src="assets/mc.png" alt="Minecraft" class="icon">
         <div class="text-content">
          <h4>Minecraft</h4>
          <p>Hosteá tu servidor de Minecraft.</p>
         </div>
        </div>
        <div class="column">
          <img src="assets/cs2.png" alt="CS2" class="icon">
          <div class="text-content">
          <h4>Counter Strike 2</h4>
          <p>Hosteá tu servidor de CS2.</p>
         </div>
        </div>
        <div class="column">
          <img src="assets/ut.png" alt="Unturned" class="icon">
          <div class="text-content">
          <h4>Unturned</h4>
          <p>Hosteá tu servidor de Unturned.</p>
         </div>
        </div>
        <div class="column">
          <img src="assets/pz.png" alt="Project Zomboid" class="icon">
          <div class="text-content">
          <h4>Project Zomboid</h4>
          <p>Hosteá tu servidor de Project Zomboid.</p>
         </div>
        </div>
      </div>
    </li>

    <li class="dropdown mega">
  <a href="#">Cloud Servers</a>
  <div class="mega-menu">
    <div class="column">
      <img src="assets/web.png" alt="web" class="icon">
      <div class="text-content">
        <h4>Pagina Web</h4>
        <p>Hosteá tu Pagina Web.</p>
      </div>
    </div>
    <div class="column">
      <img src="assets/server.png" alt="server" class="icon">
      <div class="text-content">
          <h4>VPS</h4>
          <p>Servidores privados virtuales.</p>
      </div>
    </div>
    </div>
</li>


    <li><a href="about.php">Sobre Nosotros</a></li>
    <li><a href="#soporte">Soporte</a></li>
  </ul>
</nav>
      <button class="burger" aria-label="menu" onclick="document.body.classList.toggle('nav-open')">☰</button>
    </div>
  </header>
  <main class="page-content">
    <script>
document.addEventListener('DOMContentLoaded', function() {
  // Seleccionamos todos los dropdowns
  const dropdowns = document.querySelectorAll('.dropdown');

  dropdowns.forEach(drop => {
    const link = drop.querySelector('a');
    
    // Solo para móvil
    link.addEventListener('click', function(e) {
      if (window.innerWidth <= 640) { // breakpoint del menú móvil
        e.preventDefault(); // evita seguir el enlace
        // Cerramos otros dropdowns
        dropdowns.forEach(d => {
          if(d !== drop) d.classList.remove('open');
        });
        // Toggle del dropdown actual
        drop.classList.toggle('open');
      }
    });
  });

  // Cerrar menú al tocar fuera
  document.addEventListener('click', function(e) {
    if (!e.target.closest('.nav') && window.innerWidth <= 640) {
      dropdowns.forEach(d => d.classList.remove('open'));
      document.body.classList.remove('nav-open');
    }
  });
});
</script>
