<?php
// index.php - Landing Sinysion
include 'inc/header.php';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Sinysion — Hosting en Argentina</title>
  <meta name="description" content="Hosting rápido y confiable en Argentina — Web, Gaming y VPS con soporte 24/7." />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&family=Poppins:wght@600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <section class="hero" id="home">
    <div class="hero-bg" id="heroParallax"></div>
    <div class="container hero-inner">
      <div class="hero-left">
        <h2>Hosting rápido y confiable en Argentina</h2>
        <p class="lead">Web, Gaming y VPS con soporte 24/7. Baja latencia local y prueba gratuita sin tarjeta.</p>
        <div class="hero-ctas">
          <a class="btn-primary" href="#planes">Ver Planes</a>
          <a class="btn-ghost" href="login.php">Prueba Gratis</a>
        </div>
        <ul class="hero-features">
          <li>Soporte 24/7</li>
          <li>Pago local (Mercado Pago)</li>
          <li>Pruebas sin tarjeta</li>
        </ul>
      </div>
      <div class="hero-right">
        <div class="card-3d">
          <div class="server-chip">Sinysion<br><small>Argentina</small></div>
          <div class="neon-lines"></div>
        </div>
      </div>
    </div>
  </section>

  <section id="beneficios" class="section">
    <div class="container">
      <h3 class="section-title">Por qué elegir Sinysion</h3>
      <div class="benefits">
        <div class="benefit">
          <strong>Latencia baja</strong>
          <p>Servidores locales en Argentina para experiencia fluida.</p>
        </div>
        <div class="benefit">
          <strong>Soporte 24/7</strong>
          <p>Asistencia rápida y personalizada por Discord/Email.</p>
        </div>
        <div class="benefit">
          <strong>Seguridad</strong>
          <p>Backups, firewall y certificados SSL automáticos.</p>
        </div>
        <div class="benefit">
          <strong>Prueba gratis</strong>
          <p>Servidores demo sin tarjeta para probar el servicio.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section dark-section">
        <div class="container">
        <div class="header">
            <h1>¿Qué dicen <span class="highlight">nuestros clientes?</span></h1>
        </div>
        <p class="subtitle">⭐ Algunas reseñas que demuestran nuestro compromiso contigo.</p>

        <div class="reviews-grid">
            <div class="review-card large">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Varus Sayaka">
                    <div class="user-info">
                        <h3>Varus Sayaka</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"Excellent customer service, very good customer service, good hosting for MTASA at affordable prices. I recommend it :)"</p>
            </div>
            
            <div class="review-card small">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Eric Zheng">
                    <div class="user-info">
                        <h3>Eric Zheng</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"FAST SUPPORT, GREAT PRICE, NICE SERVERS"</p>
            </div>

            <div class="review-card">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Oscar">
                    <div class="user-info">
                        <h3>Oscar</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"La mejor compañía de hosting del mundo sin duda alguna resuelven todos tus problemas al instante."</p>
            </div>

            <div class="review-card small">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Alejandro Paez">
                    <div class="user-info">
                        <h3>Alejandro Paez</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"excelente atencion del soporte principalmente de alan me ayudo y soluciono todo. genial el host"</p>
            </div>

            <div class="review-card large">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Aquatic Studios">
                    <div class="user-info">
                        <h3>Aquatic Studios</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"The service provided to us as part of Partner and public is 100% the support is super well attended, I recommend having patience because all the solutions are very convincing without a doubt #VEDXYHOST FOREVER"</p>
            </div>

            <div class="review-card small">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de TBRZZ N">
                    <div class="user-info">
                        <h3>TBRZZ N</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"Their support team is very efficient and fast, and they have all the patience to help you."</p>
            </div>

            <div class="review-card small">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Alan Gabriel">
                    <div class="user-info">
                        <h3>Alan Gabriel</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"Alan fue muy proactivo a la hora de encontrar la solucion a mi problema. Estoy muy satisfecho"</p>
            </div>

            <div class="review-card large">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Juan Camilo">
                    <div class="user-info">
                        <h3>Juan Camilo</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"El tiempo que se tomó el CEO para ayudarnos con el problema y una exelente explicación y atención gracias por todo"</p>
            </div>

            <div class="review-card small">
                <div class="review-header">
                    <img src="https://via.placeholder.com/50" alt="Foto de perfil de Valen">
                    <div class="user-info">
                        <h3>Valen</h3>
                        <div class="stars">
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                            <span class="star-filled">★</span>
                        </div>
                    </div>
                </div>
                <p>"Me solucionaron el problema muy rapido y son las 2am"</p>
            </div>
  </section>

  <!-- BLOG -->
  <section id="blog" class="section">
    <div class="container">
      <h3 class="section-title">Últimas del blog</h3>
      <div class="blog-grid">
        <article class="post">
          <div class="thumb">📰</div>
          <h5>Cómo elegir un server para Minecraft</h5>
          <p>Consejos para optimizar tu servidor y reducir lag.</p>
        </article>
        <article class="post">
          <div class="thumb">🔐</div>
          <h5>SSL y seguridad básica</h5>
          <p>Que no te agarre desprevenido: SSL, backups y firewall.</p>
        </article>
        <article class="post">
          <div class="thumb">⚙️</div>
          <h5>Pasarelas de pago en Argentina</h5>
          <p>Integrá Mercado Pago y otras opciones locales.</p>
        </article>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta section gradient-cta">
    <div class="container cta-inner">
      <h3>Tu proyecto necesita un hogar. Hospedalo en Sinysion.</h3>
      <a class="btn-cta" href="#contacto">Comenzar ahora</a>
    </div>
  </section>

  <!-- CONTACTO -->
  <section id="contacto" class="section">
    <div class="container">
      <h3 class="section-title">Contacto</h3>
      <div class="contact-grid">
        <div class="contact-info">
          <p><strong>Ubicación:</strong> Buenos Aires, Argentina</p>
          <p><strong>Email:</strong> contacto@sinysion.com</p>
          <p><strong>Instagram:</strong> @sinysion.host</p>
        </div>
        <form action="contact.php" method="post" class="contact-form">
          <label>Nombre
            <input type="text" name="nombre" required>
          </label>
          <label>Email
            <input type="email" name="email" required>
          </label>
          <label>Mensaje
            <textarea name="mensaje" rows="5" required></textarea>
          </label>
          <button class="btn-primary" type="submit">Enviar mensaje</button>
        </form>
      </div>
    </div>
  </section>

<?php
// 5) Footer común (cierra <main>, mete todo el pie de página, y cierra </html>)
include 'inc/footer.php';
?>   
  <script src="scripts.js"></script>
  <script>
    document.querySelectorAll('.review-card').forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width * 100; // Porcentaje X
            const y = (e.clientY - rect.top) / rect.height * 100; // Porcentaje Y
            card.style.setProperty('--mouse-x', `${x}%`);
            card.style.setProperty('--mouse-y', `${y}%`);
        });
    });
</script>
</body>
</html>
