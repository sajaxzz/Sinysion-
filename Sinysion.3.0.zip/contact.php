<?php
// contact.php - procesar form básico (mejorar según servidor)
if($_SERVER['REQUEST_METHOD'] !== 'POST'){
  header('Location: index.php#contacto');
  exit;
}
$nombre = strip_tags(trim($_POST['nombre'] ?? ''));
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$mensaje = strip_tags(trim($_POST['mensaje'] ?? ''));

if(!$nombre || !$email || !$mensaje){
  header('Location: index.php#contacto?status=error');
  exit;
}

$to = 'contacto@sinysion.com'; // <- reemplazá por tu mail real
$subject = "Contacto web: $nombre";
$body = "Nombre: $nombre\nEmail: $email\n\nMensaje:\n$mensaje\n";
$headers = "From: $nombre <$email>\r\n";
$headers .= "Reply-To: $email\r\n";

$sent = mail($to, $subject, $body, $headers);
if($sent){
  header('Location: index.php#contacto?status=ok');
}else{
  header('Location: index.php#contacto?status=error');
}
exit;
?>
