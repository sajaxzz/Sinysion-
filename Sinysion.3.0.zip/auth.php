<?php
// auth.php - Procesar formularios de autenticación
session_start();

// Verifica que la solicitud sea POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  header('Location: login.php'); // Redirecciona si no es un POST
  exit;
}

// Lógica para el formulario de login
if (isset($_POST['email']) && isset($_POST['password']) && !isset($_POST['username'])) {
  $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
  $password = trim($_POST['password']);

  if (!$email || empty($password)) {
    $_SESSION['error_message'] = 'Por favor, introduce un email y una contraseña válidos.';
    header('Location: login.php');
    exit;
  }
  
  // Aquí va la lógica real de autenticación (consulta a la base de datos)
  // Por ahora, solo es una simulación
  if ($email === 'test@ejemplo.com' && $password === '1234') {
    // Si los datos son correctos, inicia la sesión
    $_SESSION['user_id'] = 1;
    header('Location: /ruta/a/panel-de-usuario.php');
    exit;
  } else {
    $_SESSION['error_message'] = 'Email o contraseña incorrectos.';
    header('Location: login.php');
    exit;
  }
}

// Lógica para el formulario de registro
if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['confirm_password'])) {
  $username = trim($_POST['username']);
  $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
  $password = trim($_POST['password']);
  $confirm_password = trim($_POST['confirm_password']);
  $phone = trim($_POST['phone'] ?? '');

  // Validaciones del registro
  if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
    $_SESSION['error_message'] = 'Todos los campos son obligatorios.';
    header('Location: register.php');
    exit;
  }

  if ($password !== $confirm_password) {
    $_SESSION['error_message'] = 'Las contraseñas no coinciden.';
    header('Location: register.php');
    exit;
  }
  
  if (strlen($password) < 8) {
      $_SESSION['error_message'] = 'La contraseña debe tener al menos 8 caracteres.';
      header('Location: register.php');
      exit;
  }

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $_SESSION['error_message'] = 'Por favor, introduce un email válido.';
      header('Location: register.php');
      exit;
  }

  // Si todas las validaciones pasan, procede a guardar en la base de datos
  // Esto es solo una simulación
  $_SESSION['success_message'] = 'Cuenta creada con éxito. Por favor, inicia sesión.';
  header('Location: login.php');
  exit;
}

// Redireccion por defecto si el formulario no es reconocido
$_SESSION['error_message'] = 'Error al procesar el formulario.';
header('Location: index.php');
exit;
?>