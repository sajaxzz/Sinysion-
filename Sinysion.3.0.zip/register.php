<?php
session_start();
include 'inc/header.php';
?>
<section class="form-page">
  <div class="form-card">
    <h3 class="section-title">Crear Cuenta</h3>

    <?php if (isset($_SESSION['error_message'])): ?>
      <div class="error-message">
        <p><?= htmlspecialchars($_SESSION['error_message']) ?></p>
      </div>
      <?php unset($_SESSION['error_message']); // Limpia el mensaje para que no se muestre de nuevo ?>
    <?php endif; ?>

    <form action="auth.php" method="post" class="auth-form">
      <label>Nombre de usuario
        <input type="text" name="username" required>
      </label>
      <label>Teléfono
        <input type="tel" name="phone">
      </label>
      <label>Email
        <input type="email" name="email" required>
      </label>
      <label>Contraseña
        <input type="password" name="password" required>
      </label>
      <label>Confirmar Contraseña
        <input type="password" name="confirm_password" required>
      </label>
      <button class="btn-primary" type="submit">Crear Cuenta</button>
      <div class="form-link">
        <p>¿Ya tienes una cuenta? <a href="login.php">Iniciar Sesión</a></p>
      </div>
    </form>
  </div>
</section>
<?php include 'inc/footer.php'; ?>